// Assignment 1 Part 1: Starter Code

class Tree_Test
{

    public static void main(String[] args)
    {
        AbsTree tr = new Tree(100);
        tr.insert(50);
        tr.insert(125);
        tr.insert(150);
        tr.insert(20);
        tr.insert(75);
        tr.insert(20);
        tr.insert(90);
        tr.insert(50);
        tr.insert(125);
        tr.insert(150);
        tr.insert(75);
        tr.insert(90);

        tr.delete(20);
        tr.delete(20);
        tr.delete(20);
        tr.delete(150);
        tr.delete(100);
        tr.delete(150);
        tr.delete(125);
        tr.delete(125);
        tr.delete(50);
        tr.delete(50);
        tr.delete(50);
        tr.delete(75);
        tr.delete(90);
        tr.delete(75);
        tr.delete(90);
    }
}

class DupTree_Test
{

    public static void main(String[] args)
    {
        AbsTree tr = new DupTree(100);
        tr.insert(50);
        tr.insert(125);
        tr.insert(150);
        tr.insert(20);
        tr.insert(75);
        tr.insert(20);
        tr.insert(90);
        tr.insert(50);
        tr.insert(125);
        tr.insert(150);
        tr.insert(75);
        tr.insert(90);

        tr.delete(20);
        tr.delete(20);
        tr.delete(20);
        tr.delete(150);
        tr.delete(100);
        tr.delete(150);
        tr.delete(125);
        tr.delete(125);
        tr.delete(50);
        tr.delete(50);
        tr.delete(50);
        tr.delete(75);
        tr.delete(90);
        tr.delete(75);
        tr.delete(90);
    }
}

abstract class AbsTree
{
    public AbsTree(int n)
    {
        value = n;
        left = null;
        right = null;
    }

    public void insert(int n)
    {
        if (value == n)
            count_duplicates();
        else if (value < n)
            if (right == null)
            {
                right = add_node(n);
                right.parent = this;
            } else
                right.insert(n);
        else if (left == null)
        {
            left = add_node(n);
            left.parent = this;
        } else {
            left.insert(n);
        }
    }

    public void delete(int n)
    {
        AbsTree t = find(n);

        if (t == null) { // n is not in the tree
            System.out.println("Unable to delete " + n + " -- not in the tree!");
            return;
        }

        int c = t.get_count();
        if (c > 1)
        {
            t.set_count(c-1);
            return;
        }

        if (t.left == null && t.right == null)
        { // n is a leaf value
            if (t != this)
                case1(t);
            else
                System.out.println("Unable to delete " + n + " -- tree will become empty!");
            return;
        }
        if (t.left == null || t.right == null)
        {
            // t has one subtree only
            if (t != this)
            { // check whether t is the root of the tree
                case2(t);
                return;
            } else {
                if (t.right == null)
                    case3L(t);
                else
                    case3R(t);
                return;
            }
        }
        // t has two subtrees; go with smallest in right subtree of t
        case3R(t);
    }

    protected void case1(AbsTree t)
    {
        // remove the leaf
        if(t == t.parent.left)
            t.parent.left = null;
        if(t == t.parent.right)
            t.parent.right = null;
        t.left = null;
        t.right = null;
        t.parent = null;
        t = null;
    }

    protected void case2(AbsTree t)
    {
        // to be filled by you
        if(t == t.parent.right)
        {
            if(t.right != null)
            {
                t.parent.right = t.right;
                t.right.parent = t.parent;
                t.right = null;
                t.parent = null;
                t = null;
            }
            else if(t.left != null)
            {
                t.parent.right = t.left;
                t.left.parent = t.parent;
                t.left = null;
                t.parent = null;
                t = null;
            }
        }
        else if( t == t.parent.left)
        {
            if(t.right != null)
            {
                t.parent.left = t.right;
                t.right.parent = t.parent;
                t.right = null;
                t.parent = null;
                t = null;
            }
            else if(t.left != null)
            {
                t.parent.left = t.left;
                t.left.parent = t.parent;
                t.left = null;
                t.parent = null;
                t = null;
            }
        }

    }

    protected void case3L(AbsTree t)
    {
        // replace t.value
        AbsTree maximum = t.left.max();

        int tempValue = t.value;
        t.value = maximum.value;
        maximum.value = tempValue;

        if(maximum == maximum.parent.left)
            maximum.parent.left = null;
        if(maximum == maximum.parent.right)
            maximum.parent.right = null;
        
        if(maximum.left != null)
    	{
    		t.left = maximum.left;
    		maximum.parent = null;
    		maximum.left.parent = t;
    		maximum.left = null;      		
    	}

        maximum.parent = null;
    }

    protected void case3R(AbsTree t)
    {
        // replace t.value
        AbsTree minimum = t.right.min();

        int tempValue = t.value;
        t.value = minimum.value;
        minimum.value = tempValue;

        if(minimum == minimum.parent.left)
            minimum.parent.left = null;
        if(minimum == minimum.parent.right)
            minimum.parent.right = null;
        if(minimum.right != null)
    	{
    		t.right = minimum.right;
    		minimum.right.parent = t;
    		minimum.right = null;      		
    	}
        minimum.parent = null;
    }

    public AbsTree find(int n)
    {
        AbsTree tempTree = null;

        if(n == value)
        {
            return this;
        }
        else if (value < n)
        {
            tempTree = this.right;
            if(tempTree == null)
                return null;
            AbsTree node = tempTree.find(n);
            if(node == null)
                tempTree = null;
            else
                return node;
        }
        else if( value > n)
        {
            tempTree = this.left;
            if(tempTree == null)
                return null;
            AbsTree node = tempTree.find(n);
            if(node == null)
                tempTree = null;
            else
                return node;
        }
        return tempTree;
    }

    public AbsTree min()
    {
        AbsTree tempTree = null;
        AbsTree minNode = null;
        tempTree = this.left;
        if(tempTree == null)
            minNode = this;
        while (tempTree != null)
        {
            if(tempTree.left == null)
                minNode = tempTree;
            tempTree = tempTree.left;
        }
        return minNode;
    }

    public AbsTree max()
    {
        AbsTree tempTree = null;
        AbsTree maxNode = null;
        tempTree = this.right;
        if(tempTree == null)
            maxNode = this;
        while (tempTree != null)
        {
            if(tempTree.right == null)
                maxNode = tempTree;
            tempTree = tempTree.right;
        }
        return maxNode;
    }

    protected int value;
    protected AbsTree left;
    protected AbsTree right;
    protected AbsTree parent;

    protected abstract AbsTree add_node(int n);
    protected abstract void count_duplicates();
    protected abstract int get_count();
    protected abstract void set_count(int v);
}

class Tree extends AbsTree {
    public Tree(int n) {
        super(n);
    }

    protected AbsTree add_node(int n) {
        return new Tree(n);
    }

    protected void count_duplicates() {

    }

    protected int get_count() {
        // to be filled by you
        return 1;
    }

    protected void set_count(int v) {
        // to be filled by you
    }
}

class DupTree extends AbsTree {
    public DupTree(int n) {
        super(n);
        count = 1;
    };

    protected AbsTree add_node(int n) {
        return new DupTree(n);
    }

    protected void count_duplicates() {
        count++;
    }

    protected int get_count()
    {
        return count;
    }

    protected void set_count(int v)
    {
        count = v;
    }

    protected int count;
}
